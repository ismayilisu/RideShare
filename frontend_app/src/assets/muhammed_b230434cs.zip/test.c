#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define allowed_time 5
#define NUM_PROCESSES 5

typedef struct {
    char id;
    int remaining_time;
    int turnaround_time;
    int priority;
} Process;

Process processes[NUM_PROCESSES];
pthread_mutex_t lock;
int total_time = 0;
int unfinished_jobs;


void *rr(void *arg) {  
   
    for (int i = 0; i < NUM_PROCESSES; i++) {
        pthread_mutex_lock(&lock);
        if (processes[i].remaining_time > 0) {
            int execution_time = (processes[i].remaining_time > allowed_time) ? allowed_time : processes[i].remaining_time;
            processes[i].remaining_time -= execution_time;
            total_time += execution_time;

            if (processes[i].remaining_time == 0) {
                processes[i].turnaround_time = total_time;
                unfinished_jobs--;
            }
        }
        pthread_mutex_unlock(&lock);
        usleep(10000);
    }
    return NULL;
}

void *fcfs(void *arg) {  // FCFS
   
    for (int i = 0; i < NUM_PROCESSES; i++) {
        pthread_mutex_lock(&lock);
        if (processes[i].remaining_time > 0) {
            int execution_time = (processes[i].remaining_time > allowed_time) ? allowed_time : processes[i].remaining_time;
            processes[i].remaining_time -= execution_time;
            total_time += execution_time;

            if (processes[i].remaining_time == 0) {
                processes[i].turnaround_time = total_time;
                unfinished_jobs--;
            }
        }
        pthread_mutex_unlock(&lock);
        usleep(10000);
    }
    return NULL;
}

void *pr(void *arg) { 
   
    for (int i = 0; i < NUM_PROCESSES - 1; i++) {
        for (int j = i + 1; j < NUM_PROCESSES; j++) {
            if (processes[i].priority < processes[j].priority) { 
                Process temp = processes[i];
                processes[i] = processes[j];
                processes[j] = temp;
            }
        }
    }
    return fcfs(arg);
}

void *sjf(void *arg) {  
   
    for (int i = 0; i < NUM_PROCESSES - 1; i++) {
        for (int j = i + 1; j < NUM_PROCESSES; j++) {
            if (processes[i].remaining_time > processes[j].remaining_time) {
                Process temp = processes[i];
                processes[i] = processes[j];
                processes[j] = temp;
            }
        }
    }
    return fcfs(arg);
}

void reset_jobs() {
    for (int i = 0; i < NUM_PROCESSES; i++) {
        if (processes[i].remaining_time > 0) {
            processes[i].priority = 1.0 / processes[i].remaining_time;
        }
    }
}

int main() {
    pthread_t t0, t1, t2, t3;
    pthread_mutex_init(&lock, NULL);

  
   
    for (int i = 0; i < NUM_PROCESSES; i++) {
        processes[i].id = 'A' + i;
        printf("Process %c: ", processes[i].id);
        scanf("%d", &processes[i].remaining_time);
        processes[i].turnaround_time = 0;
        processes[i].priority = 1.0 / processes[i].remaining_time;
    }

    unfinished_jobs = NUM_PROCESSES;

   
    while (unfinished_jobs > 0) {
        pthread_create(&t0, NULL, rr, NULL);
        pthread_join(t0, NULL);

        pthread_create(&t1, NULL, fcfs, NULL);
        pthread_join(t1, NULL);

        pthread_create(&t2, NULL, pr, NULL);
        pthread_join(t2, NULL);

        pthread_create(&t3, NULL, sjf, NULL);
        pthread_join(t3, NULL);

        reset_jobs();
    }

   
    int total_turnaround_time = 0;
    for (int i = 0; i < NUM_PROCESSES; i++) {
        printf("Process %c: %d ms\n", processes[i].id, processes[i].turnaround_time);
        total_turnaround_time += processes[i].turnaround_time;
    }

    printf("\nAverage Turnaround Time: %.2f ms\n", (float)total_turnaround_time / NUM_PROCESSES);

    pthread_mutex_destroy(&lock);
    return 0;
}

