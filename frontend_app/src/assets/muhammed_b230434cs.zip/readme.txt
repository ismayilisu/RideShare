INPUT
The program prompts the user to enter the cpu process time of five processess sequentially

OUTPUT
The turnaround time of each process is shown as well as average turnaround time

TO RUN:
Compile using : gcc test.c -pthread
Run using : ./a.out 